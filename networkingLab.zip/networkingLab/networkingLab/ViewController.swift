//
//  ViewController.swift
//  networkingLab
//
//  Created by Admin on 2024-07-22.
//

import UIKit
import CoreLocation

class ViewController: UIViewController, CLLocationManagerDelegate {

    @IBOutlet weak var cityLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var humidityLabel: UILabel!
    @IBOutlet weak var windLabel: UILabel!
    @IBOutlet weak var weatherImageView: UIImageView!
    @IBOutlet weak var temperatureLabel: UILabel!
    
    let locationManager = CLLocationManager()
    let apiKey = "3c1c4860199a42d84d267e7461d542bf"

    override func viewDidLoad() {
        super.viewDidLoad()
        
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.last {
            fetchWeatherData(lat: location.coordinate.latitude, lon: location.coordinate.longitude)
            locationManager.stopUpdatingLocation()
        }
    }
    
    func fetchWeatherData(lat: Double, lon: Double) {
        let urlString = "https://api.openweathermap.org/data/2.5/weather?lat=\(lat)&lon=\(lon)&appid=\(apiKey)&units=metric"
        guard let url = URL(string: urlString) else { return }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard let data = data, error == nil else { return }
            
            do {
                let weatherResponse = try JSONDecoder().decode(WeatherResponse.self, from: data)
                DispatchQueue.main.async {
                    self.updateUI(weather: weatherResponse)
                }
            } catch {
                print("Failed to decode JSON: \(error)")
            }
        }.resume()
    }
    
    func updateUI(weather: WeatherResponse) {
        cityLabel.text = weather.name
        descriptionLabel.text = weather.weather.first?.description.capitalized
        humidityLabel.text = "Humidity: \(weather.main.humidity)%"
        windLabel.text = "Wind: \(weather.wind.speed) m/s"
        temperatureLabel.text = "Temp: \(weather.main.temp)°C"
        
        if let icon = weather.weather.first?.icon {
            let iconUrl = URL(string: "https://openweathermap.org/img/wn/\(icon)@2x.png")
            if let data = try? Data(contentsOf: iconUrl!) {
                weatherImageView.image = UIImage(data: data)
            }
        }
    }
}

struct WeatherResponse: Codable {
    let name: String
    let weather: [Weather]
    let main: Main
    let wind: Wind
}

struct Weather: Codable {
    let description: String
    let icon: String
}

struct Main: Codable {
    let temp: Double
    let humidity: Int
}

struct Wind: Codable {
    let speed: Double
}
